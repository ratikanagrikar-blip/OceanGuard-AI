/* Connects the supplied screens. It does not change the UI markup or styling. */
(() => {
  const route = (value = '') => {
    const text = value.toLowerCase().replace(/\s+/g, ' ');
    if (/data ingestion|data pipeline|dataset|upload/.test(text)) return 'data-ingestion-dashboard.html';
    if (/ai analysis|analysis workspace|psychology/.test(text)) return 'ai-analysis-workspace.html';
    if (/ocean map|map view|live map|surveillance|live feed|\bmap\b/.test(text)) return 'ocean-map-command-center.html';
    if (/alert|incident|warning/.test(text)) return /incident|warning/.test(text) ? 'incident-og-2024-net-0892.html' : 'alert-center.html';
    if (/risk|forecast/.test(text)) return 'risk-forecast.html';
    if (/species|tracking|nature_people|pets/.test(text)) return 'species-tracking.html';
    if (/report|analytics|insight|archive|assessment/.test(text)) return 'reports-insights.html';
    if (/user|team|region|security audit|manage_accounts/.test(text)) return 'user-management.html';
    if (/health|fleet|system|pipeline/.test(text)) return 'system-health.html';
    if (/overview|dashboard|command center/.test(text)) return 'authority-dashboard.html';
    return null;
  };

  // Side-panel links receive direct destinations, so they work reliably on every page.
  document.querySelectorAll('aside a, nav a').forEach((link) => {
    const destination = route(`${link.textContent || ''} ${link.querySelector('.material-symbols-outlined')?.textContent || ''}`);
    if (destination && (!link.getAttribute('href') || link.getAttribute('href') === '#')) link.href = destination;
  });

  document.addEventListener('click', (event) => {
    const control = event.target.closest('a, button, [role="button"]');
    if (!control) return;
    const label = `${control.textContent || ''} ${control.getAttribute('aria-label') || ''}`;
    const destination = route(label);
    if (destination && (control.tagName === 'BUTTON' || control.getAttribute('href') === '#')) {
      event.preventDefault();
      location.href = destination;
    }
  }, true);

  document.addEventListener('submit', (event) => {
    event.preventDefault();
    location.href = 'authority-dashboard.html';
  });
})();
